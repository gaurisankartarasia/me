import React, { useState } from 'react';
import {Link} from 'react-router-dom'
import { FaGithub, FaLinkedin, FaInstagram, FaFacebook } from "react-icons/fa";
import { FaSquareXTwitter } from "react-icons/fa6";
import './Hero.css';

const Hero: React.FC = () => {
  const [imageLoaded, setImageLoaded] = useState(false);

  return (
    <main className="hero container mx-auto p-16 text-center">
      <section>

     <div className='flex justify-center'>
     <div className="relative w-32 h-32">
              {!imageLoaded && (
                <div className="absolute inset-0 rounded-full skeleton" />
              )}
              <img
                src="https://firebasestorage.googleapis.com/v0/b/stellar-wings.appspot.com/o/IMG_20240807_235955.jpg?alt=media&token=9f0f3591-8a90-490b-bb97-ad466843ce1f" 
                className={`h-32 w-32 rounded-full ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
                alt="Me"
                onLoad={() => setImageLoaded(true)}
              />
            </div>
     </div>


        <h1 className="text-4xl md:text-6xl font-bold mb-4">
          <span className="text-4xl text-blue-500">Hi, I'm</span>
          <br />
          Gaurisankar Tarasia
        </h1>
        <h2 className="text-md md:text-md mb-8">
          Tech Enthusiast
        </h2>
<div className='flex items-center justify-center'>
  <Link to="https://github.com/gaurisankartarasia" target='_blank' className='p-3 transition-all duration-300 dark:text-white dark:hover:text-black rounded-full hover:bg-gray-200'>
  <FaGithub size={30}/>
  </Link>
  <Link to="https://linkedin.com/in/gaurisankar-tarasia-0a32a8235" target='_blank' className='p-3 transition-all duration-300 dark:text-white dark:hover:text-black rounded-full hover:bg-gray-200'>
  <FaLinkedin size={30}/>
  </Link>
  <Link to="https://x.com/gaurisankar_li2" target='_blank' className='p-3 transition-all duration-300 dark:text-white dark:hover:text-black rounded-full hover:bg-gray-200'>
  <FaSquareXTwitter size={30}/>
  </Link>
</div>

<footer className="flex flex-col items-center justify-center">
  <p className="mb-2 text-gray-500 mt-16">----- Social -----</p>
  <div className="flex items-center justify-center">
    <Link to="https://www.instagram.com/gaurisankartarasia/" target='_blank' className='p-3 text-gray-400 transition-all duration-300 dark:text-white rounded-full hover:text-gray-500'>
      <FaInstagram size={20}/>
    </Link>
    <Link to="https://www.facebook.com/gaurisankar.littu" target='_blank' className='p-3 text-gray-400 transition-all duration-300 dark:text-white rounded-full hover:text-gray-500'>
      <FaFacebook size={20}/>
    </Link>
  </div>
</footer> 

      </section>
    </main>
  );
};

export default Hero;
