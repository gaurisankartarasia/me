

import React, { useEffect, useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import NProgress from 'nprogress';
import 'nprogress/nprogress.css';
import { FaHome, FaBook } from "react-icons/fa";

const Navbar: React.FC = () => {
  const location = useLocation();
  const [imageLoaded, setImageLoaded] = useState(false);


  // Progress loader effect on route change
  useEffect(() => {
    NProgress.start();
    NProgress.done();
  }, [location]);

  // Custom styles for NProgress and skeleton loader
  useEffect(() => {
    // Remove default styles
    const nprogressStyles = document.getElementById('nprogress-styles');
    if (nprogressStyles) {
      nprogressStyles.remove();
    }

    // Add custom styles
    const style = document.createElement('style');
    style.textContent = `
      #nprogress {
        pointer-events: none;
      }
      #nprogress .bar {
        position: fixed;
        z-index: 1031;
        top: 120px;
      }
      .skeleton {
        background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
        background-size: 200% 100%;
        animation: loading 1.5s infinite;
      }
      @keyframes loading {
        0% {
          background-position: 200% 0;
        }
        100% {
          background-position: -200% 0;
        }
      }
    `;
    document.head.appendChild(style);

    return () => {
      style.remove();
    };
  }, []);

  return (
    <>
      {/* Top Section */}
      <nav className="bg-white border-gray-200 dark:bg-gray-900">
        <div className="flex flex-wrap justify-between items-center mx-auto max-w-screen-xl p-4">
          {/* Logo and Brand Name */}
          <NavLink to="/" className="flex items-center space-x-3 rtl:space-x-reverse">
            <div className="relative w-8 h-8">
              {!imageLoaded && (
                <div className="absolute inset-0 rounded-full skeleton" />
              )}
              <img
                src="https://firebasestorage.googleapis.com/v0/b/stellar-wings.appspot.com/o/IMG_20240807_235955.jpg?alt=media&token=9f0f3591-8a90-490b-bb97-ad466843ce1f" 
                className={`h-8 w-8 rounded-full ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
                alt="Me"
                onLoad={() => setImageLoaded(true)}
              />
            </div>
            <span className="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">GST</span>
          </NavLink>
       
        </div>
       
      </nav>
      {/* Bottom Section (Nav Links) */}
      <nav className="bg-gray-50 dark:bg-gray-700">
        <div className="max-w-screen-xl px-4 py-3 mx-auto">
          <div className="flex items-center">
            <ul className="flex items-center flex-row font-medium mt-0 space-x-8 rtl:space-x-reverse text-sm">
              <li>
                <NavLink
                  to="/"
                  className={({ isActive }) =>
                    isActive ? "text-blue-600 dark:text-blue-500 flex items-center" : "text-gray-900 dark:text-white flex items-center"
                  }
                >
                  <FaHome className='m-2 text-lg'/>
                  Home
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/knowledge"
                  className={({ isActive }) =>
                    isActive ? "text-blue-600 dark:text-blue-500 flex items-center" : "text-gray-900 dark:text-white flex items-center"
                  }
                >
                  <FaBook className='m-2' size={15}/>
                  Knowledge
                </NavLink>
              </li>
              {/* <li>
                <NavLink
                  to="/projects"
                  className={({ isActive }) =>
                    isActive ? "text-blue-600 dark:text-blue-500 flex items-center" : "text-gray-900 dark:text-white flex items-center"
                  }
                >
                  <FaProjectDiagram className='m-2' size={16}/>
                  Projects
                </NavLink>
              </li> */}
            </ul>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Navbar;