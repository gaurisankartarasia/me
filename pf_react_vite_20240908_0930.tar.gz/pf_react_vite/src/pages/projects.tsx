import { FC, Suspense, lazy } from "react";

// Lazy load the ProjectCard component
const ProjectCard = lazy(() => import('../components/ProjectCard'));

interface Project {
  title: string;
  description: string;
  technologies: string[];
  liveUrl?: string;
}

// Dummy project data
const projects: Project[] = [
  {
    title: "Quixxle",
    description: "A platform that connects people together. Currently it is under development.",
    technologies: ["React", "Next.js", "TypeScript"],
    liveUrl: "https://quixxle.web.app",
  },
  {
    title: "Badamba",
    description: "A local site, aims to provide some information about my village.",
    technologies: ["HTML5", "CSS3", "JavaScript"],
    liveUrl: "https://gaurisankartarasia.github.io/Badamba",
  },
  {
    title: "Stellar Wings",
    description: "An educational institution site.",
    technologies: ["HTML5", "CSS3", "JavaScript"],
    liveUrl: "https://gaurisankartarasia.github.io/StellarWings",
  },
  {
    title: "Convoya",
    description: "A small landing page for a platform.",
    technologies: ["HTML5", "CSS3", "JavaScript"],
    liveUrl: "https://gaurisankartarasia.github.io/Convoya",
  },
];

const Projects: FC = () => {
  return (
    <div className="min-h-screen bg-gray-100 p-8" id="projects">
      <h1 className="text-4xl font-bold text-center mb-12">My Projects</h1>
      {/* Suspense to lazy load ProjectCard */}
      <Suspense fallback={<div className="mx-auto">Loading Projects...</div>}>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={index} project={project} />
          ))}
        </div>
      </Suspense>
    </div>
  );
};

export default Projects;
