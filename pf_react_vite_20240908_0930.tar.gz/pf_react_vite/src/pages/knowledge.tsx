import { FC } from "react";
// Import necessary icons from react-icons
import { FaReact, FaJsSquare, FaNode, FaCss3Alt, FaGitAlt, FaLinux } from "react-icons/fa";
import { SiNextdotjs } from "react-icons/si";
import { SiTypescript } from "react-icons/si";

const Knowledge: FC = () => {
  return (
    <div className=" p-8 flex flex-col justify-center items-center ">
      <h1 className="text-4xl font-bold text-center mb-12">Knowledge</h1>

      {/* Large Box for Icons */}
      <div className="bg-white dark:bg-gray-700 shadow rounded-lg p-10 flex flex-wrap justify-center items-center gap-8 w-full max-w-4xl">
        <div className="flex flex-col justify-center items-center">
          <FaJsSquare className="text-yellow-500" size={80} />
          <span className="mt-2 text-xl font-semibold">JavaScript</span>
        </div>
        <div className="flex flex-col justify-center items-center">
          <SiTypescript className="text-blue-800 dark:text-blue-500" size={70} />
          <span className="mt-2 text-xl font-semibold">TypeScript</span>
        </div>
        <div className="flex flex-col justify-center items-center">
          <FaReact className="text-blue-500" size={80} />
          <span className="mt-2 text-xl font-semibold">React</span>
        </div>
        <div className="flex flex-col justify-center items-center">
          <FaNode className="text-green-600" size={80} />
          <span className="mt-2 text-xl font-semibold">NodeJS</span>
        </div>
        <div className="flex flex-col justify-center items-center">
          <SiNextdotjs className="text-black" size={80} />
          <span className="mt-2 text-xl font-semibold">Next.js</span>
        </div>
        <div className="flex flex-col justify-center items-center">
          <FaCss3Alt className="text-blue-600" size={80} />
          <span className="mt-2 text-xl font-semibold">CSS3</span>
        </div>
        <div className="flex flex-col justify-center items-center">
          <FaGitAlt className="text-orange-600" size={80} />
          <span className="mt-2 text-xl font-semibold">Git</span>
        </div>
        <div className="flex flex-col justify-center items-center">
          <FaLinux className="text-gray-800 dark:text-gray-100" size={80} />
          <span className="mt-2 text-xl font-semibold">Linux</span>
        </div>
      </div>
    </div>
  );
};

export default Knowledge;
